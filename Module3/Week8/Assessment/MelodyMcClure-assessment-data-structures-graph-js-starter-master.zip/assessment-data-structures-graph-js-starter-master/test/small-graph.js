module.exports = {
   'carrie':  ['humza', 'jun'],
   'farrah':  ['humza'],
   'humza':   ['carrie', 'farrah', 'jun', 'silla'],
   'jun':     ['carrie', 'silla'],
   'ophelia': ['travis'],
   'silla':   ['humza', 'yervand'],
   'travis':  ['ophelia'],
   'ursula':  ['travis'],
   'victor':  [],
   'yervand': ['silla']
}
