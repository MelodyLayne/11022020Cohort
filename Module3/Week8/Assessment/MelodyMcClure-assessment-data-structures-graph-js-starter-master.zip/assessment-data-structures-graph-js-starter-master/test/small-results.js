module.exports = [
    {'startName': 'carrie',
     'endName': 'carrie',
     'visited': ['carrie']},
    {'startName': 'carrie',
     'endName': 'humza',
     'visited': ['carrie', 'humza']},
    {'startName': 'carrie',
     'endName': 'yervand',
     'visited': ['carrie', 'jun', 'farrah', 'yervand', 'humza', 'silla']},
];
