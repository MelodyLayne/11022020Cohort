INSERT INTO fees(description, amount, invoice_id) VALUES ('Service', 96.40, 3);
INSERT INTO fees(description, amount, invoice_id) VALUES ('Service', 90.40, 4);
INSERT INTO fees(description, amount, invoice_id) VALUES ('Service', 21.04, 1);

