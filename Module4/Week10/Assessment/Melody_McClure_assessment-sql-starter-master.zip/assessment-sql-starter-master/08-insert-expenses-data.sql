INSERT INTO expenses(description, number_of_units, rate, invoice_id) VALUES ('Normal Usage', 70.00, 50.00, 4);
INSERT INTO expenses(description, number_of_units, rate, invoice_id) VALUES ('Over X Usage', 15.00, 75.00, 4);
INSERT INTO expenses(description, number_of_units, rate, invoice_id) VALUES ('Normal Usage', 81.75, 50.00, 1);
INSERT INTO expenses(description, number_of_units, rate, invoice_id) VALUES ('Normal Usage', 83.50, 50.00, 2);
INSERT INTO expenses(description, number_of_units, rate, invoice_id) VALUES ('Normal Usage', 33.00, 50.00, 3);
INSERT INTO expenses(description, number_of_units, rate, invoice_id) VALUES ('Over X Usage', 17.25, 75.00, 2);
