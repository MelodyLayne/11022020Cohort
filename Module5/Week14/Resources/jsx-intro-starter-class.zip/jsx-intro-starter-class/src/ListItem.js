const ListItem = ({ fruit }) => {
  return <li>r/{fruit}</li>;
};

export default ListItem;
