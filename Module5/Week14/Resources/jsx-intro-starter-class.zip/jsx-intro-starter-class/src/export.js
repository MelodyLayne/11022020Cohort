// named exports
// default exports

// named exports

export const num1 = 22;

export const num2 = 33;

export function add(n1, n2) {
  return n1 + n2;
}

// function subtract(n1, n2) {
//   return n1 - n2;
// }

// export default subtract;

// export default add;
