# Week 14 Assessment Learning Assets

**Included in this Repo are Week 14 Learning Objectives with and without answers as well as a CheatSheet for ES6 Imports and Exports.**

## LINKS

1. [Learning Objectives, (no answers)](./learning-objectives-empty.md)
2. [Learning Objectives With Answers](./learning-objectives-filled.md)
3. [Imports CheatSheet](./imports-cheatsheet.md)
4. [Exports CheatSheet](./exports-cheatsheet.md)
5. [Imports, Exports One-to-One](./import-export-glance.md)
6. [React CheatSheet](./react-cheatsheet.md)
7. [Week14 at-a-glance](./week14-at-a-glance.md)
