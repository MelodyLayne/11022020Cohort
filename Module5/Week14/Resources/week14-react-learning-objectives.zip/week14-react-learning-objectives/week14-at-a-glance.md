# Week 14 at-a-glance
This week you'll be introduced to React, a JavaScript library for building user interfaces. React allows you to build your frontend from small and isolated pieces of code called "components". Instead of rendering pug templates, your backend will send data that React will pass to the different components.

## Monday
- Project presentations
- Mod 5 Intro
- Half day off

## Tuesday
- You'll learn about the JSX syntax that React uses to write HTML in JavaScript files.
- You'll learn how to start a new React application.
- You'll create your first React components and pass data into them.
- Your frontend routes won't be handled by express anymore. You'll use `react-router-dom` to create frontend routes that render specific React components.
- Projects: Art Museum Project

## Wednesday
- You'll learn about React hooks, functions that will help you manage the local state and lifecycle features inside of your components. 
- You'll learn how to create a React component containing a form.
- Projects: useEffect Practice, Intro to React Forms, Explore Hooks

## Thursday
- You'll learn about React Context, which gives you a convenient way to share and update "global" data across a React application. 
- Projects: Intro to Context, Context Review with Tests, Star Trek Card Store (Optional) 

## Friday
- Solo day
- There is a practice assessment available
- Projects: Advanced Forms (Optional)
