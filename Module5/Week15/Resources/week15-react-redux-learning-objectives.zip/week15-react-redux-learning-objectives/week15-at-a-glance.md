# Week 15 at-a-glance
## Monday
With React version 15, Class components were replaced by Function Components. However, many code bases still use Class Components in parts that have not been completely migrated to use Function Components.
- Topic: Refactoring Class Components
- Project: Refactoring Widgets
## Tuesday
Redux is a pattern for managing application state. Use Redux when you have reasonable amounts of data changing over time, you need a single source of truth, and you find that approaches like keeping everything in a top-level React component's state are no longer sufficient.
- Topic: Configure a React application to use Redux
- Project: Grocery Store App
## Wednesday
Redux Thunk is a commonly used middleware for writing sync and async logic that interacts with the Redux store and simple async logic like AJAX requests. A thunk is a function that wraps an expression to delay its evaluation.
- Topic: Use Redux with Thunk and Fetching
- Project: Pokedex Thunk
## Thursday
You will learn how to put together an entire Express + React application with authentication.
- Topic: User authentication for a React application
- Project: Authenticate Me Part 1: Backend
## Friday
A "front-end build" is the process of converting code into something that can actually run on the browser. For React that means, at a minimum, converting JSX to something that browsers can understand and a lot more.
- Topic: Prepare to deploy a React application into a production environment.
- Project: Authenticate Me Part 2: Frontend, Authenticate Me Part 3: Deploy, Exploring Reacts Builds (optional)